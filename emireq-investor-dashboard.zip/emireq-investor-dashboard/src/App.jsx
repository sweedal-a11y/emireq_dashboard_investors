import { useState } from "react";
import { BrowserRouter,Routes,Route } from "react-router-dom";
import Sidebar from "./components/sidebar/Sidebar";
import Dashboard from "./pages/Dashboard";
import ProfilePage from "./pages/profile/ProfilePage";
import Portfolio from "./pages/Portfolio";
import "./App.css";

function App() {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  const toggleTheme = () => {
    setIsDarkMode(!isDarkMode);
  };

  return (
    <BrowserRouter>
    <div className={`em-app ${isDarkMode ? 'em-app--dark' : ''}`}>
      <Sidebar collapsed={sidebarCollapsed} onToggle={() => setSidebarCollapsed(!sidebarCollapsed)} />

        <main className={`em-main ${sidebarCollapsed ? 'em-main--expanded' : ''}`}>
          <Routes>
            <Route path="/" element={<Dashboard isDarkMode={isDarkMode} toggleTheme={toggleTheme} />} />
            <Route path="/profile" element={<ProfilePage toggleTheme={toggleTheme} />} />
            <Route path="/portfolio" element={<Portfolio toggleTheme={toggleTheme} />} />
          </Routes>
        </main>
    </div>
    </BrowserRouter>
  );
}

export default App;
