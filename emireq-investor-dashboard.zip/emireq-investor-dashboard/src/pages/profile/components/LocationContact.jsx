import { useState } from "react";

export default function LocationContact() {
  const [isEditing, setIsEditing] = useState(true); // Start in edit mode
  const [contactInfo, setContactInfo] = useState({
    address: "",
    linkedin: "",
    twitter: "",
  });

  const [editFormData, setEditFormData] = useState({
    address: "",
    linkedin: "",
    twitter: "",
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setEditFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSaveChanges = () => {
    setContactInfo(editFormData);
    setIsEditing(false);
  };

  const handleEdit = () => {
    setEditFormData(contactInfo);
    setIsEditing(true);
  };

  return (
    <div className="profile-section overview-section">
      <div className="profile-section-header">
        <div>
          <h3 className="profile-section-title">Location & Contact</h3>
          <p className="profile-section-subtitle">Additional contact information</p>
        </div>
        {isEditing ? (
          <button 
            className="profile-save-button" 
            onClick={handleSaveChanges}
            aria-label="Save Changes"
          >
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M13.3333 2H4.66667C3.93029 2 3.33333 2.59695 3.33333 3.33333V12.6667C3.33333 13.403 3.93029 14 4.66667 14H13.3333C14.0697 14 14.6667 13.403 14.6667 12.6667V3.33333C14.6667 2.59695 14.0697 2 13.3333 2Z" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M6 8L7.5 9.5L10.6667 6.33333" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            Save Changes
          </button>
        ) : (
          <button 
            className="profile-edit-button" 
            onClick={handleEdit}
            aria-label="Edit Location & Contact"
          >
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M11.3333 1.99998C11.5084 1.82487 11.7163 1.68698 11.9439 1.59499C12.1715 1.503 12.4142 1.45898 12.6667 1.45898C12.9191 1.45898 13.1618 1.503 13.3894 1.59499C13.617 1.68698 13.8249 1.82487 14 1.99998C14.1751 2.17509 14.313 2.38296 14.405 2.61055C14.497 2.83814 14.541 3.08084 14.541 3.33331C14.541 3.58579 14.497 3.82849 14.405 4.05608C14.313 4.28367 14.1751 4.49154 14 4.66665L5.00001 13.6666L1.33334 14.6666L2.33334 11L11.3333 1.99998Z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            Edit
          </button>
        )}
      </div>

      {isEditing ? (
        // Edit Mode - Form Inputs (Address full width, LinkedIn and Twitter side by side)
        <div className="profile-form-grid">
          <div className="profile-form-group full-width">
            <label className="profile-form-label">Address</label>
            <input
              type="text"
              name="address"
              value={editFormData.address}
              onChange={handleInputChange}
              className="profile-form-input"
              placeholder="Enter your address"
            />
          </div>
          <div className="profile-form-group">
            <label className="profile-form-label">LinkedIn</label>
            <input
              type="url"
              name="linkedin"
              value={editFormData.linkedin}
              onChange={handleInputChange}
              className="profile-form-input"
              placeholder="https://linkedin.com/in/..."
            />
          </div>
          <div className="profile-form-group">
            <label className="profile-form-label">Twitter</label>
            <input
              type="url"
              name="twitter"
              value={editFormData.twitter}
              onChange={handleInputChange}
              className="profile-form-input"
              placeholder="https://twitter.com/..."
            />
          </div>
        </div>
      ) : (
        // View Mode - Read-only Display
        <div className="overview-info-grid">
          <div className="overview-info-item">
            <span className="overview-info-label">Address</span>
            <span className="overview-info-value">{contactInfo.address || "N/A"}</span>
          </div>
          <div className="overview-info-item">
            <span className="overview-info-label">LinkedIn</span>
            {contactInfo.linkedin && contactInfo.linkedin !== "N/A" && contactInfo.linkedin !== "" ? (
              <a 
                href={contactInfo.linkedin.startsWith('http') ? contactInfo.linkedin : `https://${contactInfo.linkedin}`}
                target="_blank"
                rel="noopener noreferrer"
                className="overview-info-value overview-info-link"
              >
                {contactInfo.linkedin}
              </a>
            ) : (
              <span className="overview-info-value overview-info-link">N/A</span>
            )}
          </div>
          <div className="overview-info-item">
            <span className="overview-info-label">Twitter</span>
            {contactInfo.twitter && contactInfo.twitter !== "N/A" && contactInfo.twitter !== "" ? (
              <a 
                href={contactInfo.twitter.startsWith('http') ? contactInfo.twitter : `https://${contactInfo.twitter}`}
                target="_blank"
                rel="noopener noreferrer"
                className="overview-info-value overview-info-link"
              >
                {contactInfo.twitter}
              </a>
            ) : (
              <span className="overview-info-value overview-info-link">N/A</span>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
