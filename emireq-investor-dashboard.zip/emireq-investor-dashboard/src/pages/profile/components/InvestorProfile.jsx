import { useState } from "react";

export default function InvestorProfile() {
  const [isEditing, setIsEditing] = useState(true); // Start in edit mode
  const [investorData, setInvestorData] = useState({
    investorType: "",
    organization: "",
    investmentGoal: "",
    preferredStages: [],
  });

  const [editFormData, setEditFormData] = useState({
    investorType: "",
    organization: "",
    investmentGoal: "",
    preferredStages: [],
  });

  const availableStages = ["Seed", "MVP", "Series A", "Series B", "Growth"];

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setEditFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleToggleStage = (stage) => {
    if (editFormData.preferredStages.includes(stage)) {
      setEditFormData({
        ...editFormData,
        preferredStages: editFormData.preferredStages.filter((s) => s !== stage),
      });
    } else {
      setEditFormData({
        ...editFormData,
        preferredStages: [...editFormData.preferredStages, stage],
      });
    }
  };

  const handleSaveChanges = () => {
    setInvestorData(editFormData);
    setIsEditing(false);
  };

  const handleEdit = () => {
    setEditFormData(investorData);
    setIsEditing(true);
  };

  return (
    <div className="investor-profile-content">
      <div className="profile-section">
        <div className="profile-section-header">
          <div>
            <h3 className="profile-section-title">Investor Profile</h3>
            <p className="profile-section-subtitle">Investor strategy and preferences</p>
          </div>
          {isEditing ? (
            <button className="profile-save-button" onClick={handleSaveChanges}>
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M13.3333 2H4.66667C3.93029 2 3.33333 2.59695 3.33333 3.33333V12.6667C3.33333 13.403 3.93029 14 4.66667 14H13.3333C14.0697 14 14.6667 13.403 14.6667 12.6667V3.33333C14.6667 2.59695 14.0697 2 13.3333 2Z" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M6 8L7.5 9.5L10.6667 6.33333" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
              Save Changes
            </button>
          ) : (
            <button className="profile-edit-button" onClick={handleEdit}>
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M11.3333 1.99998C11.5084 1.82487 11.7163 1.68698 11.9439 1.59499C12.1715 1.503 12.4142 1.45898 12.6667 1.45898C12.9191 1.45898 13.1618 1.503 13.3894 1.59499C13.617 1.68698 13.8249 1.82487 14 1.99998C14.1751 2.17509 14.313 2.38296 14.405 2.61055C14.497 2.83814 14.541 3.08084 14.541 3.33331C14.541 3.58579 14.497 3.82849 14.405 4.05608C14.313 4.28367 14.1751 4.49154 14 4.66665L5.00001 13.6666L1.33334 14.6666L2.33334 11L11.3333 1.99998Z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
              Edit
            </button>
          )}
        </div>

        {isEditing ? (
          // Edit Mode - Form Inputs
          <div className="investor-profile-grid">
            <div className="investor-profile-item">
              <label className="profile-form-label">Investor Type</label>
              <input
                type="text"
                name="investorType"
                value={editFormData.investorType}
                onChange={handleInputChange}
                className="profile-form-input"
                placeholder="Angel Investor / Venture Capital"
              />
            </div>

            <div className="investor-profile-item">
              <label className="profile-form-label">Organization</label>
              <input
                type="text"
                name="organization"
                value={editFormData.organization}
                onChange={handleInputChange}
                className="profile-form-input"
                placeholder="Individual"
              />
            </div>

            <div className="investor-profile-item full-width">
              <label className="profile-form-label">Investment Goal</label>
              <input
                type="text"
                name="investmentGoal"
                value={editFormData.investmentGoal}
                onChange={handleInputChange}
                className="profile-form-input"
                placeholder="Create a balanced halal portfolio"
              />
            </div>

            <div className="investor-profile-item full-width">
              <label className="profile-form-label">Preferred Stages</label>
              <div className="preferred-stages-edit">
                {availableStages.map((stage) => (
                  <button
                    key={stage}
                    type="button"
                    className={`stage-tag ${editFormData.preferredStages.includes(stage) ? "active" : ""}`}
                    onClick={() => handleToggleStage(stage)}
                  >
                    {stage}
                  </button>
                ))}
              </div>
            </div>
          </div>
        ) : (
          // View Mode - Read-only Display
          <div className="investor-profile-view-grid">
            <div className="investor-profile-view-item">
              <span className="investor-profile-label">Investor Type</span>
              <span className="investor-profile-value">{investorData.investorType || "—"}</span>
            </div>
            <div className="investor-profile-divider"></div>
            <div className="investor-profile-view-item">
              <span className="investor-profile-label">Organization</span>
              <span className="investor-profile-value">{investorData.organization || "—"}</span>
            </div>
            <div className="investor-profile-divider"></div>
            <div className="investor-profile-view-item">
              <span className="investor-profile-label">Investment Goal</span>
              <span className="investor-profile-value">{investorData.investmentGoal || "—"}</span>
            </div>
            <div className="investor-profile-divider"></div>
            <div className="investor-profile-view-item">
              <span className="investor-profile-label">Preferred Stages</span>
              <div className="preferred-stages-display">
                {investorData.preferredStages.length > 0 ? (
                  investorData.preferredStages.map((stage) => (
                    <span key={stage} className="stage-tag-display">
                      {stage}
                    </span>
                  ))
                ) : (
                  <span className="investor-profile-value">—</span>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
