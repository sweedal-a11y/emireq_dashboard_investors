import { useState, useRef, useEffect } from "react";

export default function Interests() {
  const [sectors, setSectors] = useState([]);
  const [coins, setCoins] = useState(["Aurioux"]);
  const [geographicPreferences, setGeographicPreferences] = useState("");
  const [additionalCriteria, setAdditionalCriteria] = useState("");
  const [showSectorDropdown, setShowSectorDropdown] = useState(false);
  const [showCoinDropdown, setShowCoinDropdown] = useState(false);
  
  const sectorDropdownRef = useRef(null);
  const coinDropdownRef = useRef(null);

  const availableSectors = ["Technology", "Healthcare", "Finance", "Real Estate", "Energy", "Education"];
  const availableCoins = ["Aurioux", "Bitcoin", "Ethereum", "USDC"];

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (sectorDropdownRef.current && !sectorDropdownRef.current.contains(event.target)) {
        setShowSectorDropdown(false);
      }
      if (coinDropdownRef.current && !coinDropdownRef.current.contains(event.target)) {
        setShowCoinDropdown(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const handleAddSector = (sector) => {
    if (!sectors.includes(sector)) {
      setSectors([...sectors, sector]);
      setShowSectorDropdown(false);
    }
  };

  const handleRemoveSector = (sector) => {
    setSectors(sectors.filter((s) => s !== sector));
  };

  const handleAddCoin = (coin) => {
    if (!coins.includes(coin)) {
      setCoins([...coins, coin]);
      setShowCoinDropdown(false);
    }
  };

  const handleRemoveCoin = (coin) => {
    setCoins(coins.filter((c) => c !== coin));
  };

  const handleSavePreferences = () => {
    // Save logic here
    console.log("Saving preferences:", {
      sectors,
      coins,
      geographicPreferences,
      additionalCriteria,
    });
    // You can add API call here
  };

  return (
    <div className="interests-content">
      <div className="interests-container">
        {/* Header */}
        <div className="interests-header">
          <div className="interests-header-text">
            <h3 className="interests-title">Investment Interest</h3>
            <p className="interests-subtitle">Define your sector preferences and investment criteria</p>
          </div>
        </div>

        {/* Sectors of Interest */}
        <div className="interests-section-item">
          <label className="interests-section-label">Sectors of interest</label>
          <div className="interests-section-content">
            {sectors.length === 0 ? (
              <div className="interests-empty-state">No sectors selected</div>
            ) : (
              <div className="interests-tags-container">
                {sectors.map((sector) => (
                  <span key={sector} className="interests-tag">
                    {sector}
                    <button
                      className="interests-tag-remove"
                      onClick={() => handleRemoveSector(sector)}
                      aria-label={`Remove ${sector}`}
                    >
                      ×
                    </button>
                  </span>
                ))}
              </div>
            )}
            <div className="interests-add-button-wrapper" ref={sectorDropdownRef}>
              <button 
                className="interests-add-button"
                onClick={() => setShowSectorDropdown(!showSectorDropdown)}
              >
                + Add Sector
              </button>
              {showSectorDropdown && availableSectors.filter((sector) => !sectors.includes(sector)).length > 0 && (
                <div className="interests-dropdown">
                  {availableSectors
                    .filter((sector) => !sectors.includes(sector))
                    .map((sector) => (
                      <button
                        key={sector}
                        className="interests-dropdown-item"
                        onClick={() => handleAddSector(sector)}
                      >
                        {sector}
                      </button>
                    ))}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Divider */}
        <div className="interests-divider"></div>

        {/* Emireq Coins Interest */}
        <div className="interests-section-item">
          <label className="interests-section-label">Emireq Coins Interest</label>
          <div className="interests-section-content">
            {coins.length > 0 && (
              <div className="interests-tags-container">
                {coins.map((coin) => (
                  <span key={coin} className={`interests-tag ${coin === "Aurioux" ? "coin-tag-aurieux" : "coin-tag"}`}>
                    {coin}
                    <button
                      className="interests-tag-remove"
                      onClick={() => handleRemoveCoin(coin)}
                      aria-label={`Remove ${coin}`}
                    >
                      ×
                    </button>
                  </span>
                ))}
              </div>
            )}
            <div className="interests-add-button-wrapper" ref={coinDropdownRef}>
              <button 
                className="interests-add-button"
                onClick={() => setShowCoinDropdown(!showCoinDropdown)}
              >
                + Add Coin
              </button>
              {showCoinDropdown && availableCoins.filter((coin) => !coins.includes(coin)).length > 0 && (
                <div className="interests-dropdown">
                  {availableCoins
                    .filter((coin) => !coins.includes(coin))
                    .map((coin) => (
                      <button
                        key={coin}
                        className="interests-dropdown-item"
                        onClick={() => handleAddCoin(coin)}
                      >
                        {coin}
                      </button>
                    ))}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Divider */}
        <div className="interests-divider"></div>

        {/* Geographic Preferences */}
        <div className="interests-section-item">
          <label className="interests-section-label">Geographic Preferences</label>
          <textarea
            className="interests-textarea"
            value={geographicPreferences}
            onChange={(e) => setGeographicPreferences(e.target.value)}
            placeholder="Enter your geographic investment preferences..."
            rows="4"
          />
        </div>

        {/* Divider */}
        <div className="interests-divider"></div>

        {/* Additional Criteria */}
        <div className="interests-section-item">
          <label className="interests-section-label">Additional Criteria</label>
          <textarea
            className="interests-textarea"
            value={additionalCriteria}
            onChange={(e) => setAdditionalCriteria(e.target.value)}
            placeholder="Describe any additional criteria for your investments..."
            rows="4"
          />
        </div>

        {/* Save Button */}
        <div className="interests-save-wrapper">
          <button className="interests-save-button" onClick={handleSavePreferences}>
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M13.3333 2H2.66667C2.29848 2 2 2.29848 2 2.66667V13.3333C2 13.7015 2.29848 14 2.66667 14H13.3333C13.7015 14 14 13.7015 14 13.3333V2.66667C14 2.29848 13.7015 2 13.3333 2Z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M4.66667 2V14" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M4.66667 8H14" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            Save Preferences
          </button>
        </div>
      </div>
    </div>
  );
}

