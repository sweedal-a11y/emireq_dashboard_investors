import PersonalInformation from "./PersonalInformation";
import LocationContact from "./LocationContact";
import DocumentUpload from "./DocumentUpload";

export default function ProfileOverview({ onEditClick }) {
  return (
    <div className="profile-overview">
      {/* Personal Information */}
      <PersonalInformation />

      {/* Location & Contact */}
      <LocationContact />

      {/* KYC & Compliance */}
      <div className="profile-section overview-section">
        <div className="profile-section-header">
          <div>
            <h3 className="profile-section-title">KYC & Compliance</h3>
            <p className="profile-section-subtitle">Regulatory and compliance information</p>
          </div>
        </div>

        <div className="kyc-compliance-list">
          <div className="kyc-item kyc-item-success">
            <div className="kyc-item-left">
              <div className="kyc-icon success">
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M13.3333 4L6 11.3333L2.66667 8" stroke="#16A34A" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </div>
              <div>
                <div className="kyc-item-title">Terms & Conditions</div>
                <div className="kyc-item-status">Accepted</div>
              </div>
            </div>
            <span className="kyc-badge active">Active</span>
          </div>

          <div className="kyc-item kyc-item-warning">
            <div className="kyc-item-left">
              <div className="kyc-icon warning">
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M8 5.33333V8M8 10.6667H8.00667M14.6667 8C14.6667 11.6819 11.6819 14.6667 8 14.6667C4.3181 14.6667 1.33333 11.6819 1.33333 8C1.33333 4.3181 4.3181 1.33333 8 1.33333C11.6819 1.33333 14.6667 4.3181 14.6667 8Z" stroke="#F59E0B" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </div>
              <div>
                <div className="kyc-item-title">KYC Verification</div>
                <div className="kyc-item-status">Under review</div>
              </div>
            </div>
            <span className="kyc-badge pending">Pending</span>
          </div>

          <div className="kyc-item kyc-item-default">
            <div className="kyc-item-left">
              <div className="kyc-icon default">
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M8 1.33333C4.3181 1.33333 1.33333 4.3181 1.33333 8C1.33333 11.6819 4.3181 14.6667 8 14.6667C11.6819 14.6667 14.6667 11.6819 14.6667 8C14.6667 4.3181 11.6819 1.33333 8 1.33333Z" stroke="#6B7280" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                  <path d="M5.33333 8C5.33333 8 6.66667 9.33333 8 9.33333C9.33333 9.33333 10.6667 8 10.6667 8" stroke="#6B7280" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                  <path d="M6 6.66667C6.27614 6.66667 6.5 6.44281 6.5 6.16667C6.5 5.89052 6.27614 5.66667 6 5.66667C5.72386 5.66667 5.5 5.89052 5.5 6.16667C5.5 6.44281 5.72386 6.66667 6 6.66667Z" fill="#6B7280"/>
                  <path d="M10 6.66667C10.2761 6.66667 10.5 6.44281 10.5 6.16667C10.5 5.89052 10.2761 5.66667 10 5.66667C9.72386 5.66667 9.5 5.89052 9.5 6.16667C9.5 6.44281 9.72386 6.66667 10 6.66667Z" fill="#6B7280"/>
                </svg>
              </div>
              <div>
                <div className="kyc-item-title">Shariah Compliance</div>
                <div className="kyc-item-status">Not verified</div>
              </div>
            </div>
            <span className="kyc-badge pending">Pending</span>
          </div>
        </div>
      </div>

      {/* Document Upload */}
      <DocumentUpload />
    </div>
  );
}
