import { useState, useRef, useEffect } from "react";
import "./Portfolio.css";
import "../pages/profile/profile.css";
import avatar from "../assets/arab1.png";
import InvestmentModal from "./portfolio/InvestmentModal";

export default function Portfolio({ toggleTheme }) {
  const [profileOpen, setProfileOpen] = useState(false);
  const [selectedInvestment, setSelectedInvestment] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [searchQuery, setSearchQuery] = useState("");
  const profileRef = useRef(null);

  const investments = [
    {
      id: 1,
      name: "Synesthia",
      sector: "HealthTech",
      region: "USA",
      roi: 40,
      invested: 250000,
      currentValue: 150000,
      stage: "Growth",
      initial: "S"
    },
    {
      id: 2,
      name: "EnerTech Labs",
      sector: "Clean Energy",
      region: "Europe",
      roi: -10,
      invested: 250000,
      currentValue: 240000,
      stage: "Series A",
      initial: "E"
    },
    {
      id: 3,
      name: "Emireq Metaverse",
      sector: "VR/AR",
      region: "UAE",
      roi: 40,
      invested: 250000,
      currentValue: 230000,
      stage: "Seed",
      initial: "E"
    },
    {
      id: 4,
      name: "Voxel Capital",
      sector: "FinTech",
      region: "Asia",
      roi: 40,
      invested: 250000,
      currentValue: 220000,
      stage: "Series B",
      initial: "V"
    },
    {
      id: 5,
      name: "BioGenix",
      sector: "AL/ML",
      region: "UAE",
      roi: 40,
      invested: 250000,
      currentValue: 210000,
      stage: "Growth",
      initial: "B"
    }
  ];

  const totalInvested = investments.reduce((sum, inv) => sum + inv.invested, 0);
  const totalCurrentValue = investments.reduce((sum, inv) => sum + inv.currentValue, 0);
  const totalROI = ((totalCurrentValue - totalInvested) / totalInvested * 100).toFixed(1);
  const activeInvestments = investments.length;

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (profileRef.current && !profileRef.current.contains(e.target)) {
        setProfileOpen(false);
      }
    };

    document.addEventListener("click", handleClickOutside);
    return () => document.removeEventListener("click", handleClickOutside);
  }, []);

  const handleViewDetails = (investment) => {
    setSelectedInvestment(investment);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setSelectedInvestment(null);
  };

  const handleExportCSV = () => {
    // CSV export logic
    console.log("Exporting CSV...");
  };

  const handleExportPDF = () => {
    // PDF export logic
    console.log("Exporting PDF...");
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  return (
    <>
      <div className="header-container">
        {/* LEFT: Breadcrumbs */}
        <div className="breadcrumb-section">
          <span className="breadcrumb-item inactive">Dashboard</span>
          <span className="separator">›</span>
          <span className="breadcrumb-item active">Token</span>
        </div>

        {/* RIGHT: Header Actions */}
        <div className="em-header-actions">
          {/* THEME TOGGLE */}
          <button
            className="em-header-theme-toggle"
            onClick={toggleTheme}
            aria-label="Toggle theme"
          >
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
              <g clipPath="url(#clip0_114_12193)">
                <path d="M7.99935 11.3327C9.8403 11.3327 11.3327 9.8403 11.3327 7.99935C11.3327 6.1584 9.8403 4.66602 7.99935 4.66602C6.1584 4.66602 4.66602 6.1584 4.66602 7.99935C4.66602 9.8403 6.1584 11.3327 7.99935 11.3327Z" stroke="#2F2F33" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M8 0.666016V1.99935" stroke="#2F2F33" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M8 14V15.3333" stroke="#2F2F33" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M2.8125 2.8125L3.75917 3.75917" stroke="#2F2F33" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M12.2402 12.2402L13.1869 13.1869" stroke="#2F2F33" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M0.666016 8H1.99935" stroke="#2F2F33" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M14 8H15.3333" stroke="#2F2F33" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M2.8125 13.1869L3.75917 12.2402" stroke="#2F2F33" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M12.2402 3.75917L13.1869 2.8125" stroke="#2F2F33" strokeLinecap="round" strokeLinejoin="round"/>
              </g>
              <defs>
                <clipPath id="clip0_114_12193">
                  <rect width="16" height="16" fill="white"/>
                </clipPath>
              </defs>
            </svg>
          </button>

          {/* SEARCH */}
          <div className="em-header-search">
            <svg
              width="16"
              height="16"
              viewBox="0 0 16 16"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="em-header-search-icon"
            >
              <path
                d="M7.33333 12.6667C10.2789 12.6667 12.6667 10.2789 12.6667 7.33333C12.6667 4.38781 10.2789 2 7.33333 2C4.38781 2 2 4.38781 2 7.33333C2 10.2789 4.38781 12.6667 7.33333 12.6667Z"
                stroke="#2F2F33"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <path
                d="M13.9996 13.9996L11.0996 11.0996"
                stroke="#2F2F33"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
            <input
              type="text"
              placeholder="Search"
              className="em-header-search-input"
            />
          </div>

          {/* NOTIFICATION */}
          <button className="em-header-notification">
            <svg
              width="16"
              height="16"
              viewBox="0 0 16 16"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="em-header-notification-icon"
            >
              <path
                d="M12 5.33398C12 4.27312 11.5786 3.2557 10.8284 2.50556C10.0783 1.75541 9.06087 1.33398 8 1.33398C6.93913 1.33398 5.92172 1.75541 5.17157 2.50556C4.42143 3.2557 4 4.27312 4 5.33398C4 10.0007 2 11.334 2 11.334H14C14 11.334 12 10.0007 12 5.33398Z"
                stroke="#2F2F33"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <path
                d="M9.15237 14C9.03516 14.2021 8.86693 14.3698 8.66452 14.4864C8.46211 14.6029 8.23262 14.6643 7.99904 14.6643C7.76545 14.6643 7.53596 14.6029 7.33355 14.4864C7.13114 14.3698 6.96291 14.2021 6.8457 14"
                stroke="#2F2F33"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
            <span className="em-header-notification-dot" />
          </button>

          {/* PROFILE */}
          <div className="em-header-profile" ref={profileRef}>
            <button
              className="em-header-profile-menu"
              onClick={(e) => {
                e.stopPropagation();
                setProfileOpen((prev) => !prev);
              }}
            >
              <svg width="16" height="8" viewBox="0 0 16 8" fill="none">
                <path
                  d="M0.75 0.75H14.75"
                  stroke="#2F2F33"
                  strokeWidth="1.5"
                  strokeLinecap="round"
                />
                <path
                  d="M0.75 6.75H11.75"
                  stroke="#2F2F33"
                  strokeWidth="1.5"
                  strokeLinecap="round"
                />
              </svg>
            </button>

            <div className="em-header-profile-avatar">
              <img
                src={avatar}
                alt="User profile"
                className="em-header-avatar-img"
              />
            </div>

            {profileOpen && (
              <div className="em-profile-dropdown">
                <div className="em-profile-user">
                  <img src={avatar} alt="User" />
                  <div>
                    <div className="em-profile-name">John Doe</div>
                    <div className="em-profile-email">johndoe@gmail.com</div>
                  </div>
                </div>

                <div className="em-profile-divider" />

                <button className="em-profile-item">
                  <span className="em-profile-item-icon">👤</span>
                  My Profile
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="portfolio-content">
        {/* Page Header */}
        <div className="portfolio-header">
          <div className="portfolio-header-left">
            <h1 className="portfolio-title">Investment Portfolio</h1>
            <p className="portfolio-subtitle">Track and manage your startup investments</p>
          </div>
          <div className="portfolio-header-actions">
            <button className="export-btn export-csv" onClick={handleExportCSV}>
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M8 11.3333V2M8 11.3333L5.33333 8.66667M8 11.3333L10.6667 8.66667M2 13.3333H14" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
              Export CSV
            </button>
            <button className="export-btn export-pdf" onClick={handleExportPDF}>
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M8 2V11.3333M8 2L5.33333 4.66667M8 2L10.6667 4.66667M2 13.3333H14" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
              Export pdf
            </button>
          </div>
        </div>

        {/* Metric Cards */}
        <div className="portfolio-metrics">
          <div className="metric-card metric-blue">
            <div className="metric-icon blue">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 2C6.48 2 2 6.48 2 12C2 17.52 6.48 22 12 22C17.52 22 22 17.52 22 12C22 6.48 17.52 2 12 2ZM12 17C11.45 17 11 16.55 11 16V12C11 11.45 11.45 11 12 11C12.55 11 13 11.45 13 12V16C13 16.55 12.55 17 12 17ZM13 9H11V7H13V9Z" fill="white"/>
              </svg>
            </div>
            <div className="metric-content">
              <p className="metric-label">Total Invested</p>
              <h2 className="metric-value">{formatCurrency(totalInvested)}</h2>
            </div>
            <span className="metric-badge blue">Total</span>
          </div>

          <div className="metric-card metric-green">
            <div className="metric-icon green">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M16 6L18.29 8.29L13.41 13.17L9.41 9.17L2 16.59L3.41 18L9.41 12L13.41 16L19.71 9.71L22 12V6H16Z" fill="white"/>
              </svg>
            </div>
            <div className="metric-content">
              <p className="metric-label">Current Value</p>
              <h2 className="metric-value">{formatCurrency(totalCurrentValue)}</h2>
            </div>
            <span className="metric-badge green">Current</span>
          </div>

          <div className="metric-card metric-purple">
            <div className="metric-icon purple">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 2C6.48 2 2 6.48 2 12C2 17.52 6.48 22 12 22C17.52 22 22 17.52 22 12C22 6.48 17.52 2 12 2ZM13 17H11V15H13V17ZM13 13H11V7H13V13Z" fill="white"/>
              </svg>
            </div>
            <div className="metric-content">
              <p className="metric-label">Total ROI</p>
              <h2 className="metric-value">{totalROI}%</h2>
            </div>
            <span className="metric-badge purple">ROI</span>
          </div>

          <div className="metric-card metric-orange">
            <div className="metric-icon orange">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M20 6H16L14 4H10L8 6H4C2.9 6 2 6.9 2 8V19C2 20.1 2.9 21 4 21H20C21.1 21 22 20.1 22 19V8C22 6.9 21.1 6 20 6ZM12 17C9.24 17 7 14.76 7 12C7 9.24 9.24 7 12 7C14.76 7 17 9.24 17 12C17 14.76 14.76 17 12 17ZM12 9C10.34 9 9 10.34 9 12C9 13.66 10.34 15 12 15C13.66 15 15 13.66 15 12C15 10.34 13.66 9 12 9Z" fill="white"/>
              </svg>
            </div>
            <div className="metric-content">
              <p className="metric-label">Active Investments</p>
              <h2 className="metric-value">{activeInvestments}</h2>
            </div>
            <span className="metric-badge orange">Active</span>
          </div>
        </div>

        {/* Startup Investments Section */}
        <div className="investments-section">
          <div className="investments-header">
            <div>
              <h3 className="investments-title">
                Startup Investments
                <span className="info-icon" title="Investment portfolio information">
                  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M8 14C11.3137 14 14 11.3137 14 8C14 4.68629 11.3137 2 8 2C4.68629 2 2 4.68629 2 8C2 11.3137 4.68629 14 8 14Z" stroke="#6B7280" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                    <path d="M8 7.33333V8M8 10.6667H8.00667" stroke="#6B7280" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </span>
              </h3>
              <p className="investments-subtitle">Your portfolio of startup investments</p>
            </div>
          </div>

          {/* Filters and Search */}
          <div className="investments-filters">
            <button className="filter-btn">
              All Sectors
              <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M3 4.5L6 7.5L9 4.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </button>
            <button className="filter-btn">
              All Regions
              <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M3 4.5L6 7.5L9 4.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </button>
            <button className="filter-btn">
              Stage
              <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M3 4.5L6 7.5L9 4.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </button>
            <div className="investments-search">
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M7.33333 12.6667C10.2789 12.6667 12.6667 10.2789 12.6667 7.33333C12.6667 4.38781 10.2789 2 7.33333 2C4.38781 2 2 4.38781 2 7.33333C2 10.2789 4.38781 12.6667 7.33333 12.6667Z" stroke="#6B7280" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M13.9996 13.9996L11.0996 11.0996" stroke="#6B7280" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
              <input
                type="text"
                placeholder="Search"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="investments-search-input"
              />
            </div>
          </div>

          {/* Investments Table */}
          <div className="investments-table-container">
            <table className="investments-table">
              <thead>
                <tr>
                  <th>NAME</th>
                  <th>SECTOR</th>
                  <th>REGION</th>
                  <th>ROI</th>
                  <th>INVESTED</th>
                  <th>CURRENT VALUE</th>
                  <th>STAGE</th>
                  <th>ACTIONS</th>
                </tr>
              </thead>
              <tbody>
                {investments.map((investment) => (
                  <tr key={investment.id} className="investment-row">
                    <td>
                      <div className="investment-name">
                        <div className="investment-avatar">{investment.initial}</div>
                        <span>{investment.name}</span>
                      </div>
                    </td>
                    <td>{investment.sector}</td>
                    <td>{investment.region}</td>
                    <td>
                      <div className={`roi-badge ${investment.roi >= 0 ? 'positive' : 'negative'}`}>
                        {investment.roi >= 0 ? (
                          <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M6 2L9 5H7V10H5V5H3L6 2Z" fill="#16A34A"/>
                          </svg>
                        ) : (
                          <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M6 10L3 7H5V2H7V7H9L6 10Z" fill="#EF4444"/>
                          </svg>
                        )}
                        {investment.roi > 0 ? '+' : ''}{investment.roi}%
                      </div>
                    </td>
                    <td>{formatCurrency(investment.invested)}</td>
                    <td>{formatCurrency(investment.currentValue)}</td>
                    <td>
                      <span className="stage-badge">{investment.stage}</span>
                    </td>
                    <td>
                      <button
                        className="action-btn"
                        onClick={() => handleViewDetails(investment)}
                        aria-label="View details"
                      >
                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path d="M8 3C4.66667 3 2.07333 5.07333 1 8C2.07333 10.9267 4.66667 13 8 13C11.3333 13 13.9267 10.9267 15 8C13.9267 5.07333 11.3333 3 8 3ZM8 11.3333C6.16 11.3333 4.66667 9.84 4.66667 8C4.66667 6.16 6.16 4.66667 8 4.66667C9.84 4.66667 11.3333 6.16 11.3333 8C11.3333 9.84 9.84 11.3333 8 11.3333ZM8 6C7.08 6 6.33333 6.74667 6.33333 7.66667C6.33333 8.58667 7.08 9.33333 8 9.33333C8.92 9.33333 9.66667 8.58667 9.66667 7.66667C9.66667 6.74667 8.92 6 8 6Z" fill="#6B7280"/>
                        </svg>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          <div className="investments-pagination">
            <div className="pagination-info">
              Showing <span className="pagination-count">05</span> / 1280 Results
            </div>
            <div className="pagination-controls">
              <button className="pagination-btn" disabled={currentPage === 1}>
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M10 12L6 8L10 4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </button>
              <button className={`pagination-page ${currentPage === 1 ? 'active' : ''}`} onClick={() => setCurrentPage(1)}>1</button>
              <button className={`pagination-page ${currentPage === 2 ? 'active' : ''}`} onClick={() => setCurrentPage(2)}>2</button>
              <button className={`pagination-page ${currentPage === 3 ? 'active' : ''}`} onClick={() => setCurrentPage(3)}>3</button>
              <span className="pagination-ellipsis">...</span>
              <button className={`pagination-page ${currentPage === 20 ? 'active' : ''}`} onClick={() => setCurrentPage(20)}>20</button>
              <button className="pagination-btn" disabled={currentPage === 20}>
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M6 4L10 8L6 12" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </button>
            </div>
          </div>

          {/* Disclaimer */}
          <div className="investments-disclaimer">
            Market data is updated in real-time. Prices are for reference only and may vary across exchanges.
          </div>
        </div>
      </div>

      {/* Investment Detail Modal */}
      {isModalOpen && selectedInvestment && (
        <InvestmentModal
          investment={selectedInvestment}
          onClose={handleCloseModal}
        />
      )}
    </>
  );
}

