import { useEffect } from "react";
import "./InvestmentModal.css";

export default function InvestmentModal({ investment, onClose }) {
  useEffect(() => {
    const handleEscape = (e) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    document.addEventListener('keydown', handleEscape);
    document.body.style.overflow = 'hidden';
    
    return () => {
      document.removeEventListener('keydown', handleEscape);
      document.body.style.overflow = 'unset';
    };
  }, [onClose]);

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const gainLoss = investment.currentValue - investment.invested;
  const isPositive = gainLoss >= 0;

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <button className="modal-close" onClick={onClose} aria-label="Close modal">
          <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M15 5L5 15M5 5L15 15" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </button>

        <div className="modal-header">
          <h2 className="modal-title">{investment.name}</h2>
          <p className="modal-subtitle">Investment details and performance metrics</p>
        </div>

        <div className="modal-metrics">
          <div className="modal-metric-card">
            <p className="modal-metric-label">Invested Amount</p>
            <h3 className="modal-metric-value">{formatCurrency(investment.invested)}</h3>
          </div>
          <div className="modal-metric-card">
            <p className="modal-metric-label">Current Value</p>
            <h3 className="modal-metric-value">{formatCurrency(investment.currentValue)}</h3>
          </div>
          <div className="modal-metric-card">
            <p className="modal-metric-label">ROI</p>
            <div className="modal-metric-value-with-icon">
              <span className={`modal-metric-value ${isPositive ? 'positive' : 'negative'}`}>
                {investment.roi > 0 ? '+' : ''}{investment.roi}%
              </span>
              {isPositive ? (
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M8 2L11 5H9V13H7V5H5L8 2Z" fill="#16A34A"/>
                </svg>
              ) : (
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M8 14L5 11H7V3H9V11H11L8 14Z" fill="#EF4444"/>
                </svg>
              )}
            </div>
          </div>
          <div className="modal-metric-card">
            <p className="modal-metric-label">Gain/Loss</p>
            <h3 className={`modal-metric-value ${isPositive ? 'positive' : 'negative'}`}>
              {isPositive ? '+' : ''}{formatCurrency(gainLoss)}
            </h3>
          </div>
        </div>

        <div className="modal-details">
          <div className="modal-detail-item">
            <span className="modal-detail-label">Sector</span>
            <span className="modal-detail-value">{investment.sector}</span>
          </div>
          <div className="modal-detail-item">
            <span className="modal-detail-label">Region</span>
            <span className="modal-detail-value">{investment.region}</span>
          </div>
          <div className="modal-detail-item">
            <span className="modal-detail-label">Stage</span>
            <span className="modal-detail-badge">{investment.stage}</span>
          </div>
          <div className="modal-detail-item">
            <span className="modal-detail-label">Investment Date</span>
            <span className="modal-detail-value">March 15, 2024</span>
          </div>
          <div className="modal-detail-item">
            <span className="modal-detail-label">Status</span>
            <span className="modal-detail-badge active">Active</span>
          </div>
        </div>

        <div className="modal-actions">
          <button className="modal-btn modal-btn-secondary" onClick={onClose}>
            Close
          </button>
          <button className="modal-btn modal-btn-primary">
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M8 11.3333V2M8 11.3333L5.33333 8.66667M8 11.3333L10.6667 8.66667M2 13.3333H14" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            Download Report
          </button>
        </div>
      </div>
    </div>
  );
}

