import PersonalInformation from "./PersonalInformation";

export default function PortfolioOverview() {
  return (
    <div className="profile-overview">
      <PersonalInformation />
    </div>
  );
}
