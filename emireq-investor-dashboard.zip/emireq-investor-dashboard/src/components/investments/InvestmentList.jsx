import React from "react";
import "./InvestmentList.css";

const investments = [
  {
    name: "Dubai Real Estate Fund",
    category: "Real Estate",
    invested: "$125,000",
    value: "$148,125",
    change: "+3.2%",
  },
  {
    name: "Halal Tech Innovation",
    category: "Technology",
    invested: "$85,000",
    value: "$100,125",
    change: "+3.2%",
  },
  {
    name: "Healthcare Growth Fund",
    category: "Healthcare",
    invested: "$65,000",
    value: "$81,125",
    change: "+3.2%",
  },
  {
    name: "Islamic Finance Portfolio",
    category: "Finance",
    invested: "$55,000",
    value: "$57,600",
    change: "+3.2%",
  },
];

export default function InvestmentList() {
  return (
    <section className="investment-wrapper">
      {/* HEADER */}
      <div className="investment-header">
        <div>
          <h2 className="investment-title">
            Active Investments
            <span className="info-icon">i</span>
          </h2>
          <p className="investment-subtitle">
            Your current investment portfolio
          </p>
        </div>

        <button className="view-all-btn">View all</button>
      </div>

      {/* LIST */}
      <div className="investment-list">
        {investments.map((item, index) => (
          <div className="investment-card" key={index}>
            {/* LEFT */}
            <div className="investment-left">
              <div className="investment-icon">DR</div>

              <div>
                <div className="investment-name">{item.name}</div>
                <div className="investment-category">{item.category}</div>
              </div>
            </div>

            {/* RIGHT */}
            <div className="investment-right">
              <div className="investment-amount">
                <div className="amount-value">{item.invested}</div>
                <div className="amount-label">Invested</div>
              </div>

              <div className="investment-amount">
                <div className="amount-value">{item.value}</div>
                <div className="amount-label">Current Value</div>
              </div>

              <div className="investment-change">

                <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
<g clip-path="url(#clip0_114_12668)">
<path d="M8 3.5H11V6.5" stroke="#00B031" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M11 3.5L6.75 7.75L4.25 5.25L1 8.5" stroke="#00B031" stroke-linecap="round" stroke-linejoin="round"/>
</g>
<defs>
<clipPath id="clip0_114_12668">
<rect width="12" height="12" fill="white"/>
</clipPath>
</defs>
</svg>

               {item.change}
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
